<?php
/**
 * Plugin Name: Polylang REST Link
 * Description: Polylang çevirilerini REST API üzerinden bağlar ve şablon hook'larını tetikler
 * Version: 2.3
 * Author: Eren Akpınar
 */

// Yoast primary category meta'sını REST API üzerinden yazılabilir yap
add_action('init', function() {
  register_post_meta('post', '_yoast_wpseo_primary_category', [
    'show_in_rest'  => true,
    'single'        => true,
    'type'          => 'integer',
    'auth_callback' => function() { return current_user_can('edit_posts'); }
  ]);
});

add_action('rest_api_init', function() {

  register_rest_route('pll/v1', '/link', [
    'methods'             => 'POST',
    'permission_callback' => function() { return current_user_can('edit_posts'); },
    'callback'            => function($req) {
      $translations = $req->get_param('translations');
      if (!is_array($translations) || !function_exists('pll_save_post_translations')) {
        return new WP_REST_Response(['success' => false, 'error' => 'Polylang bulunamadı'], 400);
      }
      $int_translations = array_map('intval', $translations);
      pll_save_post_translations($int_translations);

      foreach ($int_translations as $post_id) {
        if ($post_id > 0) pll_resave_single_post($post_id);
      }

      return new WP_REST_Response(['success' => true], 200);
    }
  ]);

  register_rest_route('pll/v1', '/resave', [
    'methods'             => 'POST',
    'permission_callback' => '__return_true',
    'callback'            => function($req) {
      $post_id = intval($req->get_param('post_id'));
      if ($post_id > 0) pll_resave_single_post($post_id);
      return new WP_REST_Response(['success' => true], 200);
    }
  ]);

});

function pll_resave_single_post($post_id) {
  $post = get_post($post_id);
  if (!$post) return;

  global $wpdb;
  $wpdb->update(
    $wpdb->posts,
    ['post_modified' => current_time('mysql'), 'post_modified_gmt' => current_time('mysql', true)],
    ['ID' => $post_id]
  );

  $existing = get_post_meta($post_id, 'newsify_blog_post_meta', true);
  if (empty($existing)) {
    update_post_meta($post_id, 'newsify_blog_post_meta',
      ['newsify_single_blog_layout' => 'single-one']
    );
  }

  $existing_video = get_post_meta($post_id, 'theme_postvideo_options', true);
  if (empty($existing_video)) {
    update_post_meta($post_id, 'theme_postvideo_options', ['textm' => '']);
  }

  delete_post_meta($post_id, '_elementor_edit_mode');
  clean_post_cache($post_id);
  wp_cache_delete($post_id, 'posts');
}
